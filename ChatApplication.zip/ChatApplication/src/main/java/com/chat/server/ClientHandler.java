package com.chat.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.StringTokenizer;

public class ClientHandler implements Runnable{
	
	private String name;
	final DataInputStream din;
	final DataOutputStream dout;
	Socket s;
	boolean isLoggedIn;
	String message;
	String receiver;
	
	public ClientHandler(Socket s, DataInputStream din, DataOutputStream dout) {
		this.din=din;
		this.dout=dout;
		this.s=s;
		isLoggedIn=true;
	}

	public void run() {
		// TODO Auto-generated method stub
		String received;
		while(true)
		{
			try {
				received=din.readUTF();
				
				if(received=="logout")
				{
					this.isLoggedIn=false;
					this.s.close();
					break;
				}
				
				StringTokenizer st=new StringTokenizer(received,"#");
				message=st.nextToken();
				receiver=st.nextToken();
				
				for(ClientHandler recepient:Server.clients)
				{
					if(recepient.name.equals(receiver) && recepient.isLoggedIn)
					{
						recepient.dout.writeUTF(message);
						break;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {
			this.din.close();
			this.dout.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
