package com.chat.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class Server {
	ServerSocket ss;
	Socket s;
	static Vector<ClientHandler> clients=new Vector<ClientHandler>();
	DataInputStream din;
	DataOutputStream dout;
	public Server() throws IOException
	{
		ss=new ServerSocket(1234); 
		
		while(true)
		{
			s=ss.accept();
			
			din=new DataInputStream(s.getInputStream());
			dout=new DataOutputStream(s.getOutputStream());
			
			ClientHandler handle=new ClientHandler(s,din,dout);
			
			//Create a  new thread with this object
			Thread t=new Thread(handle);
			
			//Adding this client to active client list
			clients.add(handle);
			
			t.start();
		}
	}
}
