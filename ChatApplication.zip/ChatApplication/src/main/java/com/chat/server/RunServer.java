package com.chat.server;

import java.io.IOException;

public class RunServer {
	public static void main(String[] args) throws IOException {
		new Server();
	}
}
