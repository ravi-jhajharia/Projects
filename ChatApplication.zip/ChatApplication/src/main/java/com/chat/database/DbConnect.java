package com.chat.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnect {

	private static Connection con;
	public static Connection dbConnection()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/App_Beacon", "root", "mamta@23");
		} catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	public static void main(String[] args) {
		dbConnection();
	}
}
