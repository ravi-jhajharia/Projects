package com.chat.client;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

public class Receive implements Runnable{
	private static DataInputStream din; 
	public static String msgin="";
	
	public Receive(Socket s) throws Exception{
		 din= new DataInputStream(s.getInputStream());
	}
	
	public void run()
	{
		while(true)
		{
			try {
				msgin = din.readUTF();
				System.out.println(msgin);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}
