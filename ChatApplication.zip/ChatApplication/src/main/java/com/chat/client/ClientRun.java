package com.chat.client;

public class ClientRun {
	public static void main(String[] args) throws Exception{
		new Client();
	}
}
