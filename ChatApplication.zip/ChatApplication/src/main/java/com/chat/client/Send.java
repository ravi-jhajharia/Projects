package com.chat.client;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class Send implements Runnable{
	private static DataOutputStream dout; 
	private static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	public static String msgout="";
	public Send(Socket s) throws Exception{
		dout= new DataOutputStream(s.getOutputStream());
	}
	
	public void run()
	{
		while(true)
		{
			try {
				msgout = br.readLine();
				dout.writeUTF(msgout);
				dout.flush();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}
