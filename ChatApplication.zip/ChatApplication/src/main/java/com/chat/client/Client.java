package com.chat.client;

import java.net.Socket;

public class Client {
	
	public Client() throws Exception
	{
		Socket s=new Socket("172.16.116.59",1234);
		 Thread t1=new Thread(new Receive(s));
	     Thread t2=new Thread(new Send(s));
	     t1.start();
	     t2.start();
	     t1.sleep(100);
	     t2.sleep(100);
	}
}
