package com.automated.entities;

import java.math.BigDecimal;
import java.sql.Date;

public class Customer {
	private static Long Acc_No;
	private static String Name;
	private static String DOB;
	private static String Acc_Type;
	private static String Mobile;
	private static BigDecimal Amount;
	private static String Gender;
	private static String Password;
	
	public Customer()
	{
		
	}

	public static Long getAcc_No() {
		return Acc_No;
	}

	public static void setAcc_No(Long acc_No) {
		Acc_No = acc_No;
	}

	public static String getName() {
		return Name;
	}

	public static void setName(String name) {
		Name = name;
	}

	public static String getDOB() {
		return DOB;
	}

	public static void setDOB(String dOB) {
		DOB = dOB;
	}

	public static String getAcc_Type() {
		return Acc_Type;
	}

	public static void setAcc_Type(String acc_Type) {
		Acc_Type = acc_Type;
	}

	public static String getMobile() {
		return Mobile;
	}

	public static void setMobile(String mobile) {
		Mobile = mobile;
	}

	public static BigDecimal getAmount() {
		return Amount;
	}

	public static void setAmount(BigDecimal amount) {
		Amount = amount;
	}

	public static String getGender() {
		return Gender;
	}

	public static void setGender(String gender) {
		Gender = gender;
	}

	public static String getPassword() {
		return Password;
	}

	public static void setPassword(String password) {
		Password = password;
	}

	
}
