package com.automated.controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextField;

public class Adt {

	public Adt(JTextField txtaccno) 
	{
	txtaccno.addKeyListener(new KeyListener() {
			
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				char c=e.getKeyChar();
				if(!Character.isDigit(c))
					e.consume();
			}
			
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				/* char c=e.getKeyChar();
				if(c==KeyEvent.VK_BACK_SPACE || c==KeyEvent.VK_DELETE)
					e.consume();    */
			}
		});
	
	/* you can also use key adapter to show that key typed is invalid
	 * Here validate is a JLabel which show text "Invalid input"
	 * Validate can be shown like red text shown when there is something wrong while filling forms online
		
		txtaccno.addKeyListener(new KeyAdapter() {
		@Override
		public void keyPressed(KeyEvent e) {
		try {
			   long i=Long.parseLong(txtaccno.getText());
			validate.setText("");
		} catch (NumberFormatException e2) {
			validate.setText("Invalid input");
		}
		}
		});
	*/
	
	}
	
	public static void decimalAmount(JTextField txtAmount)
	{
		txtAmount.addKeyListener(new KeyListener() {
			
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();
				if(!(Character.isDigit(c) || c=='.'))
					e.consume();
				
			}
			
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
	}
}
