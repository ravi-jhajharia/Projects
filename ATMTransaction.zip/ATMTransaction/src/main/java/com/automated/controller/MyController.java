package com.automated.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.text.DefaultEditorKit.CutAction;

import com.automated.dbconnect.DBConnect;
import com.automated.entities.Customer;

public class MyController {
	private static Connection con;
	private static PreparedStatement pst;
	private static Statement st;
	private static ResultSet rst;
	
	public static String name="";
	public static BigDecimal amount;
	public static long account__no;
	public static BigDecimal receiverAmount;
	public static boolean verify(Customer customer) {
		
		try {
			con=DBConnect.dbConnection();
			String qry="select * from Customer where Acc_no=? and Password=?";
			pst=con.prepareStatement(qry);
			pst.setLong(1, customer.getAcc_No());
			pst.setString(2, customer.getPassword());
			
			rst=pst.executeQuery();
			if(rst.next())
			{
				name=rst.getString(2);
				account__no=rst.getLong(1);
				amount=rst.getBigDecimal(6);
				return true;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Verification exception"+e,"Error message",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}
	public static boolean storeCustomerTbl(Customer customer) {
		try {
			con=DBConnect.dbConnection();
			String qry="insert into customer(Acc_No,Name,DOB,Acc_Type,Mobile,Amount,Gender,Password)values(?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(qry);
			
			pst.setLong(1, customer.getAcc_No());
			pst.setString(2, customer.getName());
			pst.setDate(3, Date.valueOf(customer.getDOB()));
			pst.setString(4, customer.getAcc_Type());
			pst.setString(5, customer.getMobile());
			pst.setBigDecimal(6, customer.getAmount());
			pst.setString(7, customer.getGender());
			pst.setString(8, customer.getPassword());
			
			int i=pst.executeUpdate();
			if(i>0)
			{
				return true;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Data store exception"+e,"Error message",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}
	public static boolean depositToTbl(BigDecimal dept) {
		try {
			con=DBConnect.dbConnection();
			String qry="update customer set Amount=? where Acc_no=?";
			pst=con.prepareStatement(qry);
			amount=amount.add(dept);
			pst.setBigDecimal(1,amount);
			pst.setLong(2, account__no);
			
			int i=pst.executeUpdate();
			if(i>0)
			{
				return true;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Money deposit exception"+e,"Error message",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}
	public static boolean withdrawFromTbl(BigDecimal wdrl) {
		try {
			if(amount.compareTo(wdrl)<0)
				return false;
			else 
			{
				con=DBConnect.dbConnection();
				String qry="update customer set Amount=? where Acc_no=?";
				pst=con.prepareStatement(qry);
				amount=amount.subtract(wdrl);
				pst.setBigDecimal(1,amount);
				pst.setLong(2, account__no);
				
				int i=pst.executeUpdate();
				if(i>0)
				{
					return true;
				}
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Money withdrawl exception"+e,"Error message",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}
	public static boolean transferTo( Long to, BigDecimal amount2) {
		try {
				if(amount.compareTo(amount2)<0)
					return false;
				else
				{
					con=DBConnect.dbConnection();
					String qry="update customer set Amount=? where Acc_No=?";
					pst=con.prepareStatement(qry);
					amount=amount.subtract(amount2);
					
					pst.setBigDecimal(1, amount);
					pst.setLong(2, account__no);
					int i=pst.executeUpdate();
					if(i>0)
					{
					
						String aqry="update customer set Amount=? where Acc_No=?";
						pst=con.prepareStatement(aqry);
						receiverAmount=receiverAmount.add(amount2);
						
						pst.setBigDecimal(1, receiverAmount);
						pst.setLong(2, to);
						
						int j=pst.executeUpdate();
						if(j>0)
						return true;
					}
				}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Money withdrawl exception"+e,"Error message",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}
	public static boolean verifyReceiverAcc_No(long to) {
		try {
			con=DBConnect.dbConnection();
			String qry="select * from Customer where Acc_no=?";
			pst=con.prepareStatement(qry);
			pst.setLong(1, to);
			
			rst=pst.executeQuery();
			if(rst.next())
			{
				receiverAmount=rst.getBigDecimal(6);
				return true;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Receiver account verification exception "+e,"Error message",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}

}
