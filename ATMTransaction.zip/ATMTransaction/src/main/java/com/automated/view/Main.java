
package com.automated.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Main extends JFrame implements ActionListener{
	
	JButton btnRegister,btnLogin,btnExit;
	public Main()
	{
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		setResizable(false);
		setTitle("Main");
		setSize(410, 400);
		
		ImageIcon img =new ImageIcon("C:/Users/Divine/Desktop/Main.png");
		JLabel lb0=new JLabel(img);
		add(lb0);
		lb0.setSize(410,400);
		
		JLabel lb=new JLabel("Welcome");
		lb.setFont(new Font(null,Font.BOLD,20));
		lb.setForeground(Color.WHITE);
		lb0.add(lb);
		lb.setBounds(170, 0, 100, 30);
		
		btnRegister=new JButton("Register Card");
		lb0.add(btnRegister);
		btnRegister.setBounds(110, 100, 150, 20);
		
		btnLogin=new JButton("Login");
		lb0.add(btnLogin);
		btnLogin.setBounds(110, 160, 150, 20);

		btnExit=new JButton("<Exit>");
		lb0.add(btnExit);
		btnExit.setBounds(110, 220, 150, 20);
		
		btnRegister.addActionListener(this);
		btnExit.addActionListener(this);
		btnLogin.addActionListener(this);
		
	}
	
	

	public void actionPerformed(ActionEvent e) {
		
		if(btnRegister==e.getSource())
		{
			new RegisterCustomer();
			dispose();
		}
		
		else if(btnExit==e.getSource())
		{
			dispose();
		}
		
		else if(btnLogin==e.getSource())
		{
			new Login();
			dispose();
		}
	}

	
public static void main(String[] args) {
		new Main();
	}
	
}


