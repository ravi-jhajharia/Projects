package com.automated.view;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.automated.controller.MyController;

public class Transfer extends JFrame  implements ActionListener{

	JTextField txtTo,txtAmount;
	JButton btnTransfer,btnBack;
	long from,to;
	BigDecimal amount;
	public Transfer()
	{
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		setResizable(false);
		setSize(500,400);
		setTitle("Welcome :Home/Customer/Transfer");
		
		JLabel l=new JLabel(new ImageIcon(Transfer.class.getResource("/Images/transfer.png")));
		add(l);
		l.setSize(500,400);

		JLabel lb0=new JLabel("Money Transfer");
		lb0.setFont(new Font(null,Font.BOLD,20));
		l.add(lb0);
		lb0.setBounds(100, 0, 200, 30);
		
		JLabel lb1=new JLabel("Receiver acc_no");
		l.add(lb1);
		lb1.setBounds(100, 150, 100, 20);
		
		txtTo=new JTextField();
		l.add(txtTo);
		txtTo.setBounds(200, 150, 200, 20);
		
		JLabel lb2=new JLabel("Amount");
		l.add(lb2);
		lb2.setBounds(100, 200, 100, 20);
		
		txtAmount=new JTextField();
		l.add(txtAmount);
		txtAmount.setBounds(200, 200, 200, 20);
		
		btnTransfer=new JButton("Transfer");
		l.add(btnTransfer);
		btnTransfer.setBounds(75, 250, 100, 20);
		
		btnBack=new JButton("<<Back");
		l.add(btnBack);
		btnBack.setBounds(225, 250, 100, 20);
		
		btnTransfer.addActionListener(this);
		btnBack.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		if(btnTransfer==e.getSource())
		{
			to=Long.parseLong(txtTo.getText());
			amount=new BigDecimal(txtAmount.getText());
			boolean stat=MyController.verifyReceiverAcc_No(to);
			if(stat)
			{
				boolean transfr=MyController.transferTo(to,amount);
				if(transfr)
				{
					JOptionPane.showMessageDialog(null, "Thank you "+MyController.name+" Your new balance=" + MyController.amount,"Money Withdraw message",JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Insufficient balance","Error Message",JOptionPane.ERROR_MESSAGE);
				}
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Receiver Account doesn't exist","Error Message",JOptionPane.ERROR_MESSAGE);
			}
			new Home();
			dispose();
		}
		
		else if(btnBack==e.getSource())
		{
			new Home();
			dispose();
		}
		
	}


}
