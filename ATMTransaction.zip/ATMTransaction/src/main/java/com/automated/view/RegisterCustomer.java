package com.automated.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.automated.controller.Adt;
import com.automated.controller.MyController;
import com.automated.entities.Customer;

public class RegisterCustomer extends JFrame implements ActionListener{
	
	JTextField txtAccno,txtAmount,txtName,txtMobile,txtdd,txtmm,txtyyyy;
	JPasswordField pas;
	JRadioButton rdMale,rdFemale,rdinvisible;
	JComboBox<String> accType;
	JButton btnSubmit,btnReset,btnBack;
	String s[]= {"Select Acc Type","Saving","Current"};
	
	public RegisterCustomer()
	{
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		setResizable(false);
		setTitle("Welcome :Register");
		setSize(500, 650);
		
		//ImageIcon img= new ImageIcon("/Images/register.png");
		JLabel lb0=new JLabel(new ImageIcon(RegisterCustomer.class.getResource("/Images/register.png")));
		add(lb0);
		lb0.setSize(500,650);
		
		JLabel lb=new JLabel("Registration");
		lb.setFont(new Font(null,Font.BOLD,20));
		lb0.add(lb);
		lb.setBounds(175, 0, 150, 30);
		
		JLabel lb1=new JLabel("Account No");
		lb0.add(lb1);
		lb1.setBounds(100, 100, 100, 20);
		
		txtAccno=new JTextField("180000000089");
		new Adt(txtAccno);
		lb0.add(txtAccno);
		txtAccno.setBounds(200, 100, 200, 20);
		
		JLabel lb2=new JLabel("Name");
		lb0.add(lb2);
		lb2.setBounds(100, 150, 150, 20);
		
		txtName=new JTextField();
		lb0.add(txtName);
		txtName.setBounds(200, 150, 200, 20);
		
		JLabel lb3=new JLabel("D.O.B");
		lb0.add(lb3);
		lb3.setBounds(100, 200, 100, 20);
		
		JLabel d1=new JLabel("dd");
		d1.setForeground(Color.WHITE);
		lb0.add(d1);
		d1.setBounds(200, 200, 20, 20);
		
		txtdd=new JTextField();
		new Adt(txtdd);
		lb0.add(txtdd);
		txtdd.setBounds(220, 200, 30, 20);
		
		
		JLabel d2=new JLabel("mm");
		d2.setForeground(Color.WHITE);
		lb0.add(d2);
		d2.setBounds(250, 200, 30, 20);
		
	    txtmm=new JTextField();
		new Adt(txtmm);
		add(txtmm);
		txtmm.setBounds(280, 200, 30, 20);
		
		
		JLabel d3=new JLabel("yyyy");
		d3.setForeground(Color.WHITE);
		lb0.add(d3);
		d3.setBounds(310, 200, 50, 20);
		
		txtyyyy=new JTextField();
		new Adt(txtyyyy);
		lb0.add(txtyyyy);
		txtyyyy.setBounds(350, 200, 50, 20);
		
		
		JLabel lb4=new JLabel("Accoount Type");
		lb0.add(lb4);
		lb4.setBounds(100, 250, 100, 20);
		
		accType=new JComboBox<String>(s);
		lb0.add(accType);
		accType.setBounds(200, 250, 200, 20);

		JLabel lb5=new JLabel("Mobile");
		lb0.add(lb5);
		lb5.setBounds(100, 300, 100, 20);
		
		txtMobile=new JTextField();
		new Adt(txtMobile);
		lb0.add(txtMobile);
		txtMobile.setBounds(200, 300, 200, 20);
		
		JLabel lb6=new JLabel("Gender");
		lb0.add(lb6);
		lb6.setBounds(100, 350, 100, 20);
		
		rdFemale=new JRadioButton("Female");
		lb0.add(rdFemale);
		rdFemale.setBounds(200, 350, 100, 20);
		
		rdMale=new JRadioButton("Male");
		lb0.add(rdMale);
		rdMale.setBounds(300, 350, 100, 20);
		
		rdinvisible=new JRadioButton();
		lb0.add(rdinvisible);
		
		ButtonGroup bg=new ButtonGroup();
		bg.add(rdinvisible);
		bg.add(rdFemale);
		bg.add(rdMale);
		
		JLabel lb7=new JLabel("Amount");
		lb0.add(lb7);
		lb7.setBounds(100, 400, 100, 20);
		
		txtAmount=new JTextField();
		lb0.add(txtAmount);
		txtAmount.setBounds(200,400, 200, 20);
		
		JLabel lb8=new JLabel("Password");
		lb0.add(lb8);
		lb8.setBounds(100, 450, 100, 20);
		
		pas=new JPasswordField();
		lb0.add(pas);
		pas.setBounds(200, 450, 200, 20);
				
		btnSubmit=new JButton("Submit");
		lb0.add(btnSubmit);
		btnSubmit.setBounds(125, 500, 100, 20);

		btnReset=new JButton("Reset");
		lb0.add(btnReset);
		btnReset.setBounds(275, 500, 100, 20);
		
		btnBack=new JButton("<<Back");
		lb0.add(btnBack);
		btnBack.setBounds(200, 550, 100, 20);
		
		btnSubmit.addActionListener(this);
		btnReset.addActionListener(this);
		btnBack.addActionListener(this);

	}
	public void actionPerformed(ActionEvent e) {
		
		Customer customer;
		if(btnSubmit==e.getSource())
		{
			
			if(Integer.valueOf(txtdd.getText())>31 || Integer.valueOf(txtdd.getText())<1 ||Integer.valueOf(txtmm.getText())>12 ||Integer.valueOf(txtmm.getText())<1 ||Integer.valueOf(txtyyyy.getText())>2020)
			{
				JOptionPane.showMessageDialog(null, "Please fill correct date","Error message",JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				String date=txtyyyy.getText()+"-"+txtmm.getText()+"-"+txtdd.getText();
				customer=new Customer();
				BigDecimal bgd=new BigDecimal(txtAmount.getText());
				customer.setAcc_No(Long.parseLong(txtAccno.getText()));
				customer.setAcc_Type(accType.getSelectedItem().toString());
				customer.setAmount(bgd);
				customer.setDOB(date);
				if(rdMale.isSelected())
				{
					customer.setGender("Male");
				}
				if(rdFemale.isSelected())
				{
					customer.setGender("Female");
				}
				customer.setMobile(txtMobile.getText());
				customer.setName(txtName.getText());
				customer.setPassword(pas.getText());
				boolean status=MyController.storeCustomerTbl(customer);
				if(status)
				{
					JOptionPane.showMessageDialog(null, "Thank "+customer.getName()+" for registering in our bank","Data store message",JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Sorry! unable to register data","Error message",JOptionPane.ERROR_MESSAGE);
				}
			}	
			dispose();
			new Login();
		}
		
		else if(btnReset==e.getSource())
		{
			txtName.setText(null);
			txtAccno.setText(null);
			txtAmount.setText(null);
			txtdd.setText(null);
			txtmm.setText(null);
			txtyyyy.setText(null);
			pas.setText(null);
			accType.setSelectedItem(s[0]);
			rdinvisible.setSelected(true);
			txtMobile.setText(null);
			
		}
		
		else if(btnBack==e.getSource())
		{
			new Main();
			dispose();
		}
	}

}


