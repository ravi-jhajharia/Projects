package com.automated.view;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Home extends JFrame implements ActionListener{

	JButton btnDeposit,btnTransfer,btnWithdarwl,btnLogout;
	public Home()
	{
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		setResizable(false);
		setSize(500,300);
		setTitle("Welcome :Home/Customer");
		
		JLabel lb0=new JLabel(new ImageIcon(Home.class.getResource("/Images/login.png")));
		add(lb0);
		lb0.setSize(500,300);
		
		JLabel lb=new JLabel("We heartly welcome you to your account ");
		lb.setFont(new Font(null, Font.BOLD, 16));
		lb0.add(lb);
		lb.setBounds(90, 0, 400, 20);
				
		btnDeposit=new JButton("Deposit");
		lb0.add(btnDeposit);
		btnDeposit.setBounds(125, 80, 100, 30);
		
		btnTransfer=new JButton("Transfer");
		lb0.add(btnTransfer);
		btnTransfer.setBounds(275, 80, 100, 30);
		
		btnWithdarwl=new JButton("Withdrawl");
		lb0.add(btnWithdarwl);
		btnWithdarwl.setBounds(125, 150, 100, 30);
		
		btnLogout=new JButton("Logout");
		lb0.add(btnLogout);
		btnLogout.setBounds(275, 150, 100, 30);
		
		btnDeposit.addActionListener(this);
		btnLogout.addActionListener(this);
		btnTransfer.addActionListener(this);
		btnWithdarwl.addActionListener(this);
		

	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(btnTransfer==e.getSource())
		{
			int i=JOptionPane.showConfirmDialog(null, "Do you want to transfer money","Money Transfer mesasge",JOptionPane.INFORMATION_MESSAGE);
			if(i==0)
			{
				new Transfer();
				dispose();
			}	
			else 
			{
				JOptionPane.showMessageDialog(null, "Money transfer canceled","Cancel message",JOptionPane.ERROR_MESSAGE);
			}
		}
		
		else if(btnDeposit==e.getSource())
		{
			int i=JOptionPane.showConfirmDialog(null, "Do you want to deposit money","Money Deposit message",JOptionPane.INFORMATION_MESSAGE);
			if(i==0)
			{
				new Deposit();
				dispose();
			}	
			else 
			{
				JOptionPane.showMessageDialog(null, "Money deposit canceled","Cancel message",JOptionPane.ERROR_MESSAGE);
			}
		}
		
		else if(btnWithdarwl==e.getSource())
		{
			int i=JOptionPane.showConfirmDialog(null, "Do you want to witdraw money","Money Withdrawl message",JOptionPane.INFORMATION_MESSAGE);
			if(i==0)
			{
				new Withdrawl();
				dispose();
			}	
			else 
			{
				JOptionPane.showMessageDialog(null, "Money withdraw canceled","Cancel message",JOptionPane.ERROR_MESSAGE);
			}
		}
		
		else if(btnLogout==e.getSource())
		{
			new Login();
			dispose();
		}
	}
	public static void main(String[] args) {
		new Home();
	}
	
}
