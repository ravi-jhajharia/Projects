package com.automated.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.automated.controller.Adt;
import com.automated.controller.MyController;
import com.automated.entities.Customer;

public class Login extends JFrame implements ActionListener{
	
	JTextField txtaccno;
	JPasswordField ps;
	JButton btnLogin,btnReset;
	public Login()
	{
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		setResizable(false);
		setSize(600,375);
		setTitle("Login");
		
		Font f=new Font(null, Font.BOLD,16);
		
		ImageIcon img=new ImageIcon("F:/wallpapers/nat.jpg"); 
		JLabel lb=new JLabel(img);
		add(lb);
		lb.setSize(600, 375);
		
		JLabel lb1=new JLabel("Welcome");
		lb1.setFont(new Font(null, Font.BOLD, 26));
		lb1.setForeground(Color.white);
		lb.add(lb1);
		lb1.setBounds(240, 0, 120, 30);
		
		JLabel lb2=new JLabel("Account No");
		lb.add(lb2);
		lb2.setFont(f);
		lb2.setForeground(Color.white);
		lb2.setBounds(130, 80, 140, 20);
		
		txtaccno=new JTextField();
		new Adt(txtaccno);	
		lb.add(txtaccno);
		txtaccno.setBounds(270, 80, 200, 20);
		
		JLabel lb3=new JLabel("Password");
		lb.add(lb3);
		lb3.setFont(f);
		lb3.setForeground(Color.white);
		lb3.setBounds(130, 140, 140	, 20);
		
		ps=new JPasswordField();
		lb.add(ps);
		ps.setBounds(270, 140, 200, 20);
		
		btnLogin=new JButton("Login");
		lb.add(btnLogin);
		btnLogin.setBounds(175, 200, 100, 20);
		
		btnReset=new JButton("Reset");
		lb.add(btnReset);
		btnReset.setBounds(325, 200, 100, 20);
		
		btnLogin.addActionListener(this);
		btnReset.addActionListener(this);
		
		
		
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Customer customer = null;
		if(btnLogin==e.getSource())
		{
			Long lg=new Long(txtaccno.getText());
			customer.setAcc_No(lg);
			customer.setPassword(ps.getText());
			boolean status=MyController.verify(customer);
			if(status)
			{
				new Home();
				dispose();
			}
			
			else
			{
				JOptionPane.showMessageDialog(null, "Invalid person","Error message",JOptionPane.ERROR_MESSAGE);
			}
		}
	    
		else if(btnReset==e.getSource())
		{
			txtaccno.setText(null);
			ps.setText(null);
		}
	}
	
	
}
