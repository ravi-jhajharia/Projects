package com.automated.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.automated.controller.MyController;
import com.automated.entities.Customer;

public class Withdrawl extends JFrame implements ActionListener{

	JTextField txtwithdraw;
	JButton btnWithdraw,btnBack;
	BigDecimal wdrl;
	public Withdrawl()
	{
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		setResizable(false);
		setSize(400,300);
		setTitle("Welcome :Home/Customer/Withdraw");
		
		JLabel l0=new JLabel(new ImageIcon(Withdrawl.class.getResource("/Images/withdrawl.png"))); 
		add(l0);
		l0.setSize(400,300);
		
		JLabel lb0=new JLabel("Money Withdraw");
		lb0.setFont(new Font(null,Font.BOLD,20));
		lb0.setForeground(Color.WHITE);
		l0.add(lb0);
		lb0.setBounds(100, 0, 200, 30);

		JLabel lb=new JLabel("Amount");
		lb.setForeground(Color.WHITE);
		l0.add(lb);
		lb.setBounds(100, 100, 100, 20);
		
		txtwithdraw=new JTextField();
		l0.add(txtwithdraw);
		txtwithdraw.setBounds(200, 100, 200, 20);
		
		btnWithdraw=new JButton("Withdraw");
		lb.setForeground(Color.WHITE);
		l0.add(btnWithdraw);
		btnWithdraw.setBounds(75, 150, 100, 20);
		
		btnBack=new JButton("<<Back");
		l0.add(btnBack);
		btnBack.setBounds(225, 150, 100, 20);
		
		btnWithdraw.addActionListener(this);
		btnBack.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		if(btnWithdraw==e.getSource())
		{
			wdrl=new BigDecimal(txtwithdraw.getText());
			boolean withd=MyController.withdrawFromTbl(wdrl);
			if(withd)
			{
				JOptionPane.showMessageDialog(null, "Thank you "+MyController.name+" Your remaining balance="+ MyController.amount,"Money Withdraw message",JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Insufficient balance","Error Message",JOptionPane.ERROR_MESSAGE);
			}
			new Home();
			dispose();
		}
		
		else if(btnBack==e.getSource())
		{
			new Home();
			dispose();
		}
		
	}

}
