package com.automated.dbconnect;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class DBConnect {
	private static Connection con;
	public static Connection dbConnection()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/App_Beacon", "root", "mamta@23");
			System.out.println("Connection ready :"+con);
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e,"Database Connection error",JOptionPane.ERROR_MESSAGE);
		}
		return con;
	}

	public static void main(String[] args) {
		dbConnection();
	}
}
