package in.ravi.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import in.ravi.cotroller.*;
import in.ravi.entities.Employee;
import in.ravi.entities.Student;

public class Login extends JFrame implements ActionListener{
	JButton btnLogin,btnReset,btnEmpRegister,btnStRegister,btnExit;
	JTextField txtEmail;
	JPasswordField ps;
	JComboBox cbPanel;
	
	String [] Select= {"Select user Panel","Employee","Student"}; 
	
	public Login()
	{
		setVisible(true);
		setSize(580, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(null);
		setTitle("Welcome:Login");
		
		//..........BackGround.......
		JLabel bg=new JLabel();
		bg.setIcon(new ImageIcon(Login.class.getResource("/image/login.png")));
		add(bg);
		bg.setSize(580, 400);
		
		//..........Heading..........
		JLabel lb=new JLabel("Authentication");
		bg.add(lb);
		lb.setForeground(Color.WHITE);
		lb.setFont(new Font(null, Font.BOLD, 26));
		lb.setBounds(200, 0, 200, 20);
			
		//..........Select User Panel.
		JLabel lb1=new JLabel("User Panel    :");
		bg.add(lb1);
		lb1.setForeground(Color.WHITE);
		lb1.setBounds(100, 70, 100, 20);
		
		cbPanel=new JComboBox(Select);
		bg.add(cbPanel);
		cbPanel.setBounds(200, 70, 280, 20);
		cbPanel.setToolTipText("Select user ID type student or Employee");
		
		//..........User Name........
		JLabel lb2=new JLabel("User E-Mail  :");
		bg.add(lb2);
		lb2.setForeground(Color.WHITE);
		lb2.setBounds(100, 120, 100, 20);
		
		txtEmail=new JTextField();
		bg.add(txtEmail);
		Restrict.Email(txtEmail);
		txtEmail.setBounds(200, 120, 280, 20);
		txtEmail.setToolTipText("<html><center><b>User Name</b></center>Enter email as your your User Name <br>Only a-z, @ and . is valid<br>e.g abc@gmail.com</html>");
		
		//..........Password.........
		JLabel lb3=new JLabel("Password    :");
		bg.add(lb3);
		lb3.setForeground(Color.WHITE);
		lb3.setBounds(100, 170, 100, 20);
		
		ps=new JPasswordField();
		bg.add(ps);
		ps.setBounds(200, 170, 280, 20);
		ps.setToolTipText("<html><center><b>Password</b></center>Enter your Password</html>");
				
		//..........Copyright.......
		JLabel lb4=new JLabel("@Copyright (c) 2019 MyProject Beacon");
		bg.add(lb4);
		lb4.setForeground(Color.WHITE);
		lb4.setBounds(10, 340, 250, 20);
		
		//..........Buttons.........		
		btnEmpRegister=new JButton("Register Employee");
		bg.add(btnEmpRegister);
		btnEmpRegister.setBounds(120, 210, 150, 20);
		btnEmpRegister.setToolTipText("For employee training registeration click here");

		btnStRegister=new JButton("Register Student");
		bg.add(btnStRegister);
		btnStRegister.setBounds(310, 210, 150, 20);
		btnStRegister.setToolTipText("For basic training registeration as student click here");
		
		btnLogin=new JButton("Login");
		bg.add(btnLogin);
		btnLogin.setBounds(170, 250, 100, 20);
		btnLogin.setToolTipText("<html><b>Login</html>");

		btnReset=new JButton("Reset");
		bg.add(btnReset);
		btnReset.setBounds(310, 250, 100, 20);
		btnReset.setToolTipText("<html><b>Reset</html>");
		
		btnExit=new JButton("<Exit>");
		bg.add(btnExit);
		btnExit.setBounds(240, 290, 100, 20);
		btnExit.setToolTipText("<html><b>Exit</html>");
		
		btnLogin.addActionListener(this);
		btnEmpRegister.addActionListener(this);
		btnStRegister.addActionListener(this);
		btnReset.addActionListener(this);
		btnExit.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		Student student;
		Employee employee;
		String uEmail,password;
		
		if(btnLogin==e.getSource())
		{
			if(cbPanel.getSelectedItem().toString().equals("Select user Panel"))
			{
				JOptionPane.showMessageDialog(null, "Please Select User Panel");
			}
			else if(cbPanel.getSelectedItem().toString().equals("Employee"))
			{
				employee=new Employee();
				employee.setEmail(txtEmail.getText());
				employee.setPassword(ps.getText());
				
				boolean status=ES_Controller.verifyEmp(employee);
				if(status)
				{
					JOptionPane.showMessageDialog(null, "Welcome "+ES_Controller.userpanelname);
					new EmployeeMain();
					dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Sorry invalid ID or password");
				}
			}
			else if(cbPanel.getSelectedItem().toString().equals("Student"))
			{
				student=new Student();
				student.setEmail(txtEmail.getText().toString());
				student.setPassword(ps.getText().toString());
				
				boolean status=ES_Controller.verifyStudent(student);
				if(status)
				{
					JOptionPane.showMessageDialog(null, "Welcome "+ES_Controller.userpanelname);
					new StudentMain();
					dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Sorry invalid ID or password");
				}
			}
		}
		
		if(btnEmpRegister==e.getSource())
		{
				new EmpRegister();
				dispose();
		}
		
		if(btnStRegister==e.getSource())
		{
			new StRegister();
			dispose();
		}
		
		if(btnReset==e.getSource())
		{
			txtEmail.setText(null);
			ps.setText(null);
			cbPanel.setSelectedItem(null);
		}
		
		if(btnExit==e.getSource())
		{
			dispose();
		}
	}
	
}
