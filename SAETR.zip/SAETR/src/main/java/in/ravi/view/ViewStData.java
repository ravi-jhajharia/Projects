package in.ravi.view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class ViewStData extends JFrame implements ActionListener{
	
	JTable tbl;
	JScrollPane scpane;
	JButton btnback;
	String call[]= {"Id","Rollno","Name","Course","Branch","Email","Password","Gender","State"};

	public ViewStData(String stData[][]) {
	
		setVisible(true);
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(1024,200);
		setTitle("Welcome :Student/Home/Data");
				
		//..........BackGround.......
		JLabel bk=new JLabel();
		bk.setIcon(new ImageIcon(Login.class.getResource("/image/View.png")));
		add(bk);
		bk.setSize(1024, 200);
		
		tbl=new JTable(stData,call);
		bk.add(tbl);
		tbl.setForeground(Color.WHITE);
		tbl.setBackground(new Color(0,0,0,100));

		scpane=new JScrollPane(tbl);
		bk.add(scpane);
		scpane.setBackground(new Color(0,0,0,100));
		scpane.setBounds(0, 25, 1014, 70);
				
		btnback=new JButton("<<Back");
		bk.add(btnback);
		btnback.setBounds(462, 120, 100, 20);
		btnback.setToolTipText("<HTML><b>Back<HTML>");
		
		btnback.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(btnback==e.getSource())
		{
			new StudentMain();
			dispose();
		}
	}

}
