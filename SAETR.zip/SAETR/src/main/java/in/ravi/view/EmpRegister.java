package in.ravi.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import in.ravi.cotroller.ES_Controller;
import in.ravi.cotroller.Restrict;
import in.ravi.entities.Employee;

public class EmpRegister extends JFrame implements ActionListener{
	JTextField txtName,txtEmail,txtMobile,txtSalary,txtDesignation;
	JPasswordField pas;
	JRadioButton rdMale,rdFemale,rdinvisible;
	JComboBox cbState;
	JButton btnSubmit,btnReset,btnBack;
	
	public EmpRegister()
	{
		String s[] ={"","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chattisgarh","Goa","Gujrat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal"};
		//..........Layout...........
		setVisible(true);
		setSize(500, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(null);
		setTitle("Form");
		
		//..........BackGround.......
		JLabel bk=new JLabel();
		bk.setIcon(new ImageIcon(Login.class.getResource("/image/empRegUpdate.png")));
		add(bk);
		bk.setSize(500, 600);
				
		//..........Heading.........
		JLabel lb=new JLabel("Employee Detail");
		bk.add(lb);
		lb.setForeground(Color.WHITE);
		lb.setFont(new Font(null, Font.BOLD, 20));
		lb.setBounds(150, 0, 200, 30);
		
		//..........Name.............
		JLabel lb1=new JLabel("Name ");
		bk.add(lb1);
		lb1.setForeground(Color.WHITE);
		lb1.setBounds(100, 50, 100, 20);
		
		txtName=new JTextField();
		bk.add(txtName);
		Restrict.Alphabet(txtName);
		txtName.setBounds(200, 50, 200, 20);
		txtName.setToolTipText("Enter name");
		
		//..........User Email.........
		JLabel lb2=new JLabel("E-Mail ");
		bk.add(lb2);
		lb2.setForeground(Color.WHITE);
		lb2.setBounds(100, 100, 100, 20);
		
		txtEmail=new JTextField();
		bk.add(txtEmail);
		Restrict.Email(txtEmail);
		txtEmail.setBounds(200, 100, 200, 20);
		txtEmail.setToolTipText("<html><center><b>User Name</b></center>Enter email as User Name <br>Only a-z, @ and . is valid<br>e.g abc@gmail.com</html>");
		
		//..........Password............
		JLabel lb3=new JLabel("Password");
		bk.add(lb3);
		lb3.setForeground(Color.WHITE);
		lb3.setBounds(100, 150, 100, 20);
		
		pas=new JPasswordField();
		bk.add(pas);
		pas.setBounds(200, 150, 200, 20);
		pas.setToolTipText("<html><center><b>Password</b></center>Set password for this account</html>");
		
		//..........Mobile..............
		JLabel lb4=new JLabel("Mobile Number");
		bk.add(lb4);
		lb4.setForeground(Color.WHITE);
		lb4.setBounds(100, 200, 100, 20);
		
		txtMobile=new JTextField();
		bk.add(txtMobile);
		Restrict.mobileNo(txtMobile);
		txtMobile.setBounds(200, 200,200,20);
		txtMobile.setToolTipText("<html><b>Mobile number</html>");
		
		//..........Gender..............
		JLabel lb5=new JLabel("Gender:");
		bk.add(lb5);
		lb5.setForeground(Color.WHITE);
		lb5.setBounds(100, 250, 100, 20);
		
		rdMale=new JRadioButton("Male");
		bk.add(rdMale);
		rdMale.setBounds(200, 250, 100, 20);
		
		rdFemale=new JRadioButton("Female");
		bk.add(rdFemale);
		rdFemale.setBounds(300, 250, 100, 20);
		
		rdinvisible=new JRadioButton();
		add(rdinvisible);
		ButtonGroup bg=new ButtonGroup();
		bg.add(rdMale);
		bg.add(rdFemale);
		bg.add(rdinvisible);
		
		//..........State..............
		JLabel lb6=new JLabel("State");
		bk.add(lb6);
		lb6.setForeground(Color.WHITE);
		lb6.setBounds(100, 300, 100, 20);
		
		cbState=new JComboBox(s);
		bk.add(cbState);
		cbState.setBounds(200, 300, 200, 20);
		cbState.setToolTipText("<html><b>Select state</html>");
		
		//..........Designation............
		JLabel lb7=new JLabel("Designation");
		bk.add(lb7);
		lb7.setForeground(Color.WHITE);
		lb7.setBounds(100, 350, 100, 20);
		
		txtDesignation=new JTextField();
		bk.add(txtDesignation);
		Restrict.Alphabet(txtDesignation);
		txtDesignation.setBounds(200, 350, 200, 20);
		txtDesignation.setToolTipText("<html><b>Enter designation</html>");
		
		//..........Salary.............
		JLabel lb8=new JLabel("Salary              Rs");
		bk.add(lb8);
		lb8.setForeground(Color.WHITE);
		lb8.setBounds(100, 400, 100, 20);
		
		txtSalary=new JTextField();
		bk.add(txtSalary);
		Restrict.Salary(txtSalary);
		txtSalary.setBounds(200, 400, 200, 20);
		txtSalary.setToolTipText("Enter monthly salary");
		
		//..........Buttons............
		btnSubmit=new JButton("Submit");
		bk.add(btnSubmit);
		btnSubmit.setBounds(125, 450, 100, 20);
		btnSubmit.setToolTipText("<html><b>Submit</html>");
		
		btnReset=new JButton("Reset");
		bk.add(btnReset);
		btnReset.setBounds(275, 450, 100, 20);
		btnReset.setToolTipText("<html><b>Reset</html>");
		
		btnBack=new JButton("<< Back");
		bk.add(btnBack);
		btnBack.setBounds(200, 500, 100, 20);
		btnBack.setToolTipText("<html><b>Back</html>");
		
		btnSubmit.addActionListener(this);
		btnReset.addActionListener(this);
		btnBack.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		Employee employee;
		if(btnSubmit==e.getSource())
		{
			employee=new Employee();
			employee.setDesignation(txtDesignation.getText());
			employee.setEmail(txtEmail.getText());
			if(rdMale.isSelected())
			{
				employee.setGender("Male");
			}
			else
			{
				employee.setGender("Female");
			}
			employee.setMobile(txtMobile.getText());
			employee.setName(txtName.getText());
			employee.setPassword(pas.getText());
			employee.setSalary(Integer.valueOf(txtSalary.getText()));
			employee.setState(cbState.getSelectedItem().toString());
			
			boolean stat=ES_Controller.storeEmployeetbl(employee);
			if(stat)
			{
				JOptionPane.showMessageDialog(null,"Thank you "+employee.getName());
				dispose();
				new Login();
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Sorry "+employee.getName());
				new EmpRegister();
				dispose();
			}
		}
		if(btnReset==e.getSource())
		{
			txtName.setText(null);
			txtEmail.setText(null);
			pas.setText(null);
			txtMobile.setText(null);
			rdinvisible.setSelected(true);
			cbState.setSelectedItem(null);
			txtDesignation.setText(null);
			txtSalary.setText(null);
		}
		
		if(btnBack==e.getSource())
		{
			new Login();
			dispose();
		}
	}
}
