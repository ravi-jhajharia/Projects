package in.ravi.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import in.ravi.cotroller.ES_Controller;

public class EmployeeMain extends JFrame implements ActionListener{
	
	JButton btnView,btnUpdate,btnDelete,btnLogout;
	
	public EmployeeMain()
	{
		setVisible(true);
		setSize(400, 380);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(null);
		setTitle("Welcome:Employee/Home");
		
		//..........BackGround.......
		JLabel bk=new JLabel();
		bk.setIcon(new ImageIcon(Login.class.getResource("/image/Main.png")));
		add(bk);
		bk.setSize(400, 380);
				
		//..........Heading..........
		JLabel lb=new JLabel("Welcome "+ES_Controller.userpanelname+" to your data management home");
		bk.add(lb);
		lb.setForeground(Color.WHITE);
		lb.setFont(new Font(null, Font.BOLD, 18));
		lb.setBounds(0, 0, 400, 30);

		//..........Buttons.........		
		btnView=new JButton("View");
		btnView.setFont(new Font(null, Font.ITALIC, 22));
		bk.add(btnView);
		btnView.setBounds(40, 60, 135, 115);
		btnView.setToolTipText("<html><b>View your data<html>");

		btnUpdate=new JButton("Update");
		btnUpdate.setFont(new Font(null, Font.ITALIC, 22));
		bk.add(btnUpdate);
		btnUpdate.setBounds(215, 60, 135, 115);
		btnUpdate.setToolTipText("<html><b>Update your data<html>");

		btnDelete=new JButton("Delete");
		btnDelete.setFont(new Font(null, Font.ITALIC, 22));
		bk.add(btnDelete);
		btnDelete.setBounds(40, 205, 135, 115);
		btnDelete.setToolTipText("<html><b>Delete your data<html>");

		btnLogout=new JButton("Logout");
		btnLogout.setFont(new Font(null, Font.ITALIC, 22));
		bk.add(btnLogout);
		btnLogout.setBounds(215, 205, 135, 115);
		btnLogout.setToolTipText("<html><b>Logout<html>");

		btnView.addActionListener(this);
		btnUpdate.addActionListener(this);
		btnDelete.addActionListener(this);
		btnLogout.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(btnView==e.getSource())
		{
			String empData[][]=ES_Controller.viewEmpData();
			if(empData!=null)
			{
				new ViewEmpData(empData);
				dispose();
			} 
			else
			{
				JOptionPane.showMessageDialog(null, "Unable to retrieve data ","Data view",JOptionPane.ERROR_MESSAGE);
			}
		}
		
		else if(btnUpdate==e.getSource())
		{
			int i=JOptionPane.showConfirmDialog(null, "Do you want to update data");
			if(i==0)
			{	
				new UpdateEmpData();
				dispose();
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Data update canceled ","Cancel message",JOptionPane.INFORMATION_MESSAGE);
			}
		}
		
		else if(btnDelete==e.getSource())
		{
			int i=JOptionPane.showConfirmDialog(null, "Delete Data");
			if(i==0)
			{
				boolean stat=ES_Controller.deleteDatabyId(ES_Controller.id);
				if(stat)
				{
					JOptionPane.showMessageDialog(null, "Data delete for Id "+ES_Controller.id+" !Successful","Delete message",JOptionPane.INFORMATION_MESSAGE);
					new Login();
					dispose();
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "Unable to delete data for Id "+ES_Controller.id,"Delete message",JOptionPane.ERROR_MESSAGE);
				}
			}
			else 
			{
				JOptionPane.showMessageDialog(null, "Data delete cancled ","Cancel message",JOptionPane.CANCEL_OPTION);
			}
		}
		else if(btnLogout==e.getSource())
		{
			new Login();
			dispose();
		}
	}

}
