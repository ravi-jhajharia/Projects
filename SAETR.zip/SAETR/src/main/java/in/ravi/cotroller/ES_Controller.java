package in.ravi.cotroller;

import java.io.ObjectInputStream.GetField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import in.ravi.db.DbConnect;
import in.ravi.entities.Employee;
import in.ravi.entities.Student;
import in.ravi.view.ViewEmpData;
import in.ravi.view.ViewStData;

public class ES_Controller {

	private static Connection con;
	private static PreparedStatement pst;
	private static Statement st;
	private static ResultSet rst;
	public static String userpanelname="";
	public static int id;
	public static String empData[][]=new String[1][9];
	public static String stData[][]=new String[1][9];
	
	public static boolean verifyEmp(Employee employee) {
		// TODO Auto-generated method stub
		try {   
			con=DbConnect.dbConnection();
			String aqry="select * from Employee where Email=? and Password=?";
			pst=con.prepareStatement(aqry);
			pst.setString(1, employee.getEmail());
			pst.setString(2, employee.getPassword());

			rst=pst.executeQuery();
			if(rst.next())
			{
				userpanelname=rst.getString(2);
				id=rst.getInt(1);
				return true;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data verification exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}
	
	public static boolean storeEmployeetbl(Employee employee) {
		// TODO Auto-generated method stub
	
		try {
			con=DbConnect.dbConnection();
			String qry= "insert into Employee (Name,Email,Password,Mobile,Gender,State,Designation,Salary) values(?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(qry);
			pst.setString(1, employee.getName());
			pst.setString(2, employee.getEmail());
			pst.setString(3, employee.getPassword());
			pst.setString(4, employee.getMobile());
			pst.setString(5, employee.getGender());
			pst.setString(6, employee.getState());
			pst.setString(7, employee.getDesignation());
			pst.setInt(8, employee.getSalary());
			
			int i=pst.executeUpdate();
			if(i>0)
				return true;
			
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data register/login exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}

	public static boolean verifyStudent(Student student) {
		// TODO Auto-generated method stub
		try {
			con=DbConnect.dbConnection();
			String  aqry="select * from Student where Email=? and Password=?";
			pst=con.prepareStatement(aqry);
			pst.setString(1, student.getEmail());
			pst.setString(2, student.getPassword());
			
			rst=pst.executeQuery();
			if(rst.next())
			{
				userpanelname=rst.getString(3);
				id=rst.getInt(1);
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data verification exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}

	public static boolean storeStudenttbl(Student student) {
		// TODO Auto-generated method stub
		try {
			con=DbConnect.dbConnection();	
			String bqry= "insert into student(Rollno,Name,Course,Branch,Email,Password,Gender,State) values(?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(bqry);
			pst.setInt(1, student.getRollno());
			pst.setString(2, student.getName());
			pst.setString(3, student.getCourse());
			pst.setString(4, student.getBranch());
			pst.setString(5, student.getEmail());
			pst.setString(6, student.getPassword());
			pst.setString(7, student.getGender());
			pst.setString(8, student.getState());
			
			int i=pst.executeUpdate();
			if(i>0)
				return true;

		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data register/login exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}

	public static boolean deleteDatabyId(int id2) {
		// TODO Auto-generated method stub

		try {
			con=DbConnect.dbConnection();
			String del="delete from Employee where Id=?";
			pst=con.prepareStatement(del);
			
			pst.setInt(1, id);
			int i=pst.executeUpdate();
			if(i>0)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data delete exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		
		return false;
	}

	public static boolean updateDatabyId(Employee employee) {
		// TODO Auto-generated method stub
		try {
			con=DbConnect.dbConnection();
			String upd="update Employee set Name=? ,Email=? ,Password=? ,Mobile=? ,Gender=? ,State=? ,Designation=? ,Salary=? where Id=?";
			pst=con.prepareStatement(upd);
			
			pst.setString(1, employee.getName());
			pst.setString(2, employee.getEmail());
			pst.setString(3, employee.getPassword());
			pst.setString(4, employee.getMobile());
			pst.setString(5, employee.getGender());
			pst.setString(6, employee.getState());
			pst.setString(7, employee.getDesignation());
			pst.setInt(8, employee.getSalary());
			pst.setInt(9, id);
			
			int i=pst.executeUpdate();
			if(i>0)
				return true;
			
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data update exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}

	public static boolean deleteStData(int id2) {
		// TODO Auto-generated method stub
		try {
			con=DbConnect.dbConnection();
			String dlt="delete from student where Id=?";
			pst=con.prepareStatement(dlt);
			
			pst.setInt(1, id2);
			int i=pst.executeUpdate();
			if(i>0)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data delete exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}

	public static boolean updateStudenttbl(Student student) {
		// TODO Auto-generated method stub
		try {
			con=DbConnect.dbConnection();
			String upd="update Student set Rollno=? , Name=? , Course=? , Branch=? ,Email=? ,Password=? ,Gender=? ,State=?  where Id=?";
			pst=con.prepareStatement(upd);
			pst.setInt(1, student.getRollno());
			pst.setString(2, student.getName());
			pst.setString(3, student.getCourse());
			pst.setString(4, student.getBranch());
			pst.setString(5, student.getEmail());
			pst.setString(6, student.getPassword());
			pst.setString(7, student.getGender());
			pst.setString(8, student.getState());
			pst.setInt(9, id);
			
			int i=pst.executeUpdate();
			if(i>0)
				return true;
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data update exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return false;
	}

	public static String[][] viewStData() {
		// TODO Auto-generated method stub
		try {
			con=DbConnect.dbConnection();
			String view="select * from student where Id="+id;
			st=con.createStatement();
			rst=st.executeQuery(view);
			if(rst.next())
			{
				for(int i=1;i<=stData[0].length;i++)
				{
					if(i==1 || i==2 )
						stData[0][i-1]=Integer.toString(rst.getInt(i));
					else
						stData[0][i-1]=rst.getString(i);
				}
				return stData;
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data retrieve exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return null;
	}

	public static String[][] viewEmpData() {
		// TODO Auto-generated method stub
		try {
			con=DbConnect.dbConnection();
			String view="select * from Employee where Id="+id;
			st=con.createStatement();
			rst=st.executeQuery(view);
			if(rst.next())
			{
				for(int i=1;i<=empData[0].length;i++)
				{
					if(i==1 || i==9)
						empData[0][i-1]=Integer.toString(rst.getInt(i));
					else 
						empData[0][i-1]=rst.getString(i);
				}
				return empData;
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Data retrieve exception "+e,"Exception",JOptionPane.ERROR_MESSAGE);
		}
		return null;
	}

}
