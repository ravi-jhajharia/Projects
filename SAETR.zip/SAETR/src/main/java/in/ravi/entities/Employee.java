package in.ravi.entities;

public class Employee {
	
	private int Id;
	private String Name;
	private String Email;
	private String Password;
	private String Designation;
	private String Mobile;
	private String State;
	private String Gender;
	private int Salary;
	
	public Employee()
	{
		
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getMobile() {
		return Mobile;
	}

	public void setMobile(String mobile) {
		Mobile = mobile;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public int getSalary() {
		return Salary;
	}

	public void setSalary(int salary) {
		Salary = salary;
	}

	@Override
	public String toString()
	{
		return "Employee[Id="+Id+",Name="+Name+",Email="+Email+",Password="+Password+",Designation="+Designation+",Mobile="+Mobile+",State="
				+State+",Gender="+Gender+",Salary="+Salary+"]";
	}
}
