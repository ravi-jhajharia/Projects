package in.ravi.entities;

public class Student {
	
	private static int Id;
	private static int Rollno;
	private static String Name;
	private static String Course;
	private static String Branch;
	private static String Email;
	private static String Password;
	private static String Gender;
	private static String State;
	
	public static int getId() {
		return Id;
	}

	public static void setId(int id) {
		Id = id;
	}

	public static int getRollno() {
		return Rollno;
	}

	public static void setRollno(int rollno) {
		Rollno = rollno;
	}

	public static String getName() {
		return Name;
	}

	public static void setName(String name) {
		Name = name;
	}

	public static String getCourse() {
		return Course;
	}

	public static void setCourse(String course) {
		Course = course;
	}

	public static String getBranch() {
		return Branch;
	}

	public static void setBranch(String branch) {
		Branch = branch;
	}

	public static String getEmail() {
		return Email;
	}

	public static void setEmail(String email) {
		Email = email;
	}

	public static String getPassword() {
		return Password;
	}

	public static void setPassword(String password) {
		Password = password;
	}

	public static String getGender() {
		return Gender;
	}

	public static void setGender(String gender) {
		Gender = gender;
	}

	public static String getState() {
		return State;
	}

	public static void setState(String state) {
		State = state;
	}

	public Student()
	{
		
	}
	
	@Override
	public String toString() {
		return "Student [Id=" + Id + ", Name=" + Name + ", Email=" + Email+",Course="+Course+",Branch="+Branch
				+ ", Password=" + Password + ",State="+State+",Gender="+Gender+",Rollno="+Rollno+"]";
	}

	
}
