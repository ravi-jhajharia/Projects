package in.ravi.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnect {
	
	private static Connection con;             //SQL statements are executed and results are returned within the context of a connection. and con is its object
	public static Connection dbConnection()
	{
		try {
			    Class.forName("com.mysql.jdbc.Driver");                                                       //tries to get the driver from com.mysql.jdbc.Driver
			    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/app_beacon", "root", "mamta@23");//DriverManager manages the driver  while 
				System.out.println("Connection ready:"+con);								                    //getConnection try to connect to database by URL provided			
		
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	public static void main(String[] args) {
		
		dbConnection();
	}
}
